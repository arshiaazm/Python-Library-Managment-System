quiz = {
    1: {"question": "Who is the best teacher in the world?",
        "answer": "Sir Umar Iqbal"},

    2: {"question": "Who is called the god of lightning in Avengers?",
        "answer": "Thor"},

    3: {"question": "Who carries a shield of American flag theme in Avengers?",
        "answer": "Captain America"},

    4: {"question": "Which avenger is green in color?",
        "answer": "Hulk"},

    5: {"question": "Which avenger can change it's size?",
        "answer": "AntMan"},

    6: {"question": "Which Avenger is red in color and has mind stone?",
        "answer": "Vision"},

    7: {"question": "Who discovered penicillin?",
        "answer": "Alexander Fleming"},

    8: {"question": "Who was the first woman to win a Nobel Prize (in 1903)?",
        "answer": "Marie Curie"},

    9: {"question": "What part of the atom has no electric charge?",
        "answer": "Neutron"},

    10: {"question": "What is the symbol for potassium?",
         "answer": "K"},

    11: {"question": "What is meteorology the study of?",
         "answer": "The weather"},

    12: {"question": "Which planet is the hottest in the solar system?",
         "answer": "Venus"},

    13: {"question": "Which natural disaster is measured with a Richter scale?",
         "answer": "Earthquakes"},

    14: {"question": "Which animal can be seen on the Porsche logo?",
         "answer": "Horse"},

    15: {"question": "Which Williams sister has won more Grand Slam titles?",
         "answer": "Serena"},

    16: {"question": "What country won the very first FIFA World Cup in 1930?",
         "answer": "Uruguay"},

    17: {"question": "In what year was the first-ever Wimbledon Championship held?",
         "answer": "1877"},

    18: {"question": "What other name does “corn” go by?",
         "answer": "Maize"},

    19:	{"question": "What’s the primary ingredient in hummus?",
         "answer": "Chickpeas"},

    20: {"question": "Which country produces the most coffee in the world?",
         "answer": "Brazil"},

    21: {"question": "What percentage of our bodies is made up of water?",
         "answer": "60-65%"},

    22: {"question": "Which element is said to keep bones strong?",
         "answer": "Calcium"},

    23: {"question": "How many times does the heartbeat per day?",
         "answer": "About 100,000"},

    24: {"question": "What is the smallest country in the world?",
         "answer": "Vatican City"},

    25: {"question": "Which continent is the largest?",
         "answer": "Asia"},

}