import pymysql
#Add your own database name and password here to reflect in the code
mypass = ""
mydatabase="lms"

con = pymysql.connect(host="localhost",user="root",password=mypass,database=mydatabase, port=3306)
cur = con.cursor()
